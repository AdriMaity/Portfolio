# EA96 — Portfolio

Personal developer portfolio for EA96.

## Deploy to Vercel (3 ways)

---

### Option 1 — Drag & Drop (Fastest, no account needed initially)

1. Go to [vercel.com](https://vercel.com)
2. Sign up / log in
3. Click **"Add New → Project"**
4. Drag the entire `ea96-vercel` folder into the upload area
5. Click **Deploy**
6. Done — you'll get a live URL like `ea96-vercel.vercel.app`

---

### Option 2 — Vercel CLI

```bash
# Install Vercel CLI
npm install -g vercel

# Navigate to this folder
cd ea96-vercel

# Deploy
vercel

# Follow prompts — first deploy asks to link/create a project
# Subsequent deploys:
vercel --prod
```

---

### Option 3 — GitHub + Vercel (Recommended for auto-deploys)

1. Create a new GitHub repo (public or private)
2. Push this folder:
   ```bash
   git init
   git add .
   git commit -m "init: EA96 portfolio"
   git remote add origin https://github.com/YOUR_USERNAME/ea96-portfolio.git
   git push -u origin main
   ```
3. Go to [vercel.com](https://vercel.com) → **"Add New → Project"**
4. Import your GitHub repo
5. Vercel auto-detects static site — no build settings needed
6. Click **Deploy**

Every `git push` to `main` will auto-redeploy.

---

## Custom Domain

1. In Vercel dashboard → your project → **Settings → Domains**
2. Add your domain (e.g. `ea96.dev`)
3. Update your DNS records as shown by Vercel
4. SSL is automatic

---

## Files

```
ea96-vercel/
├── index.html     ← The entire portfolio (self-contained)
├── vercel.json    ← Routing + cache + security headers
└── README.md      ← This file
```

Everything is embedded in `index.html` — fonts load from Google Fonts CDN, no build step required.
